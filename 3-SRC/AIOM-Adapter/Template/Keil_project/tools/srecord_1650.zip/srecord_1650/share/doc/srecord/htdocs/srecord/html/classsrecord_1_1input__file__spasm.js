var classsrecord_1_1input__file__spasm =
[
    [ "~input_file_spasm", "classsrecord_1_1input__file__spasm.html#adcbddabc84a904ff02c1c95d642a7bc7", null ],
    [ "read", "classsrecord_1_1input__file__spasm.html#ad2ee8ff615652994207adea3bd785c6f", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__spasm.html#af11c9bcabcc6ecb71ccc4847235d87e1", null ],
    [ "format_option_number", "classsrecord_1_1input__file__spasm.html#a65bea7dacae0d5ef318075aebb52b037", null ]
];