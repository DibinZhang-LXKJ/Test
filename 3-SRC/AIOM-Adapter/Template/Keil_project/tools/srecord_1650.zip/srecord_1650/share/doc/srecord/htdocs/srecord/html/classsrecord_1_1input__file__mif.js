var classsrecord_1_1input__file__mif =
[
    [ "~input_file_mif", "classsrecord_1_1input__file__mif.html#a4ba541a205631b2c39977653918735ab", null ],
    [ "read", "classsrecord_1_1input__file__mif.html#adf9e32fb2c1f0e2adefd050e2b94fb59", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__mif.html#aede496ba679963fa6205609a8fa4109d", null ],
    [ "format_option_number", "classsrecord_1_1input__file__mif.html#a6d3090a8c53c2bea72f28154b6acf8f7", null ]
];