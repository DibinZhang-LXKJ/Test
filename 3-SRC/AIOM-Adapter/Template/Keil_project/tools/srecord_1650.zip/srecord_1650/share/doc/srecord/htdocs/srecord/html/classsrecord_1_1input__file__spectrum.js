var classsrecord_1_1input__file__spectrum =
[
    [ "~input_file_spectrum", "classsrecord_1_1input__file__spectrum.html#a9d632d78cebf50db69e1755edf8d5a5f", null ],
    [ "read", "classsrecord_1_1input__file__spectrum.html#ac61fed009b1dabbc9e81f72a7cf1d21e", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__spectrum.html#a317eb2b21f1812884bac75621a963509", null ],
    [ "format_option_number", "classsrecord_1_1input__file__spectrum.html#a3a2bf1ee5b621cb4ca6fcc2f5f18645f", null ]
];