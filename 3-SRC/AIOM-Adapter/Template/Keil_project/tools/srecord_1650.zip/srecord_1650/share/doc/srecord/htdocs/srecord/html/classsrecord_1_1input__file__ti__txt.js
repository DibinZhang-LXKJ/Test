var classsrecord_1_1input__file__ti__txt =
[
    [ "~input_file_ti_txt", "classsrecord_1_1input__file__ti__txt.html#a4ea3e32b48fb0efe58384de170a18cb2", null ],
    [ "read", "classsrecord_1_1input__file__ti__txt.html#aab65de123ca325781026ef753ce02474", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__ti__txt.html#a4e90229428d53127cbd23f56d69980bc", null ],
    [ "format_option_number", "classsrecord_1_1input__file__ti__txt.html#ae062ebd2e27fff5b5452c50ab68f365a", null ]
];