var classsrecord_1_1input__file__idt =
[
    [ "~input_file_idt", "classsrecord_1_1input__file__idt.html#aeef29cfb5476943418d348eaed94432a", null ],
    [ "read", "classsrecord_1_1input__file__idt.html#a850f21f702b8b84b9ccd1e776d5cd377", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__idt.html#a558a237baf2cf613c2fc8dc3015f967a", null ],
    [ "is_binary", "classsrecord_1_1input__file__idt.html#a0f4308f741b364e3a0da512084b6f708", null ],
    [ "format_option_number", "classsrecord_1_1input__file__idt.html#ab428a1b1101d5fb533e8aaa1f5a12ccc", null ]
];