var classsrecord_1_1input__file__trs80 =
[
    [ "~input_file_trs80", "classsrecord_1_1input__file__trs80.html#a06c534dcc518712f3e7795b9e9dab8f4", null ],
    [ "read", "classsrecord_1_1input__file__trs80.html#a1b2722a080373d9909c85eb957dfe01c", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__trs80.html#aca60af1824222292247eaa56d6747c97", null ],
    [ "is_binary", "classsrecord_1_1input__file__trs80.html#a554b2cf612b7a54c2367dc9c034a2bfa", null ],
    [ "format_option_number", "classsrecord_1_1input__file__trs80.html#a398b0227c18136f5ed64238401555f40", null ]
];