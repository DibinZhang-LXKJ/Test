var classsrecord_1_1input__file__tektronix =
[
    [ "~input_file_tektronix", "classsrecord_1_1input__file__tektronix.html#a548f5b97ab93c0f05aaeed0682157e1f", null ],
    [ "read", "classsrecord_1_1input__file__tektronix.html#a8fed958cea40b2cae46991cb7379c23d", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__tektronix.html#a133f679e3be0ce17fd8d49ba35cd4b10", null ],
    [ "format_option_number", "classsrecord_1_1input__file__tektronix.html#a62a144095df3a422f7421f0f981a99f3", null ]
];