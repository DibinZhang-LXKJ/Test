var classsrecord_1_1input__file__ti__tagged =
[
    [ "~input_file_ti_tagged", "classsrecord_1_1input__file__ti__tagged.html#a3c22d383b2c00337f2469e473fd4f231", null ],
    [ "read", "classsrecord_1_1input__file__ti__tagged.html#a3c8bb25114c1ae6ceecc8922d344af64", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__ti__tagged.html#a0f3925ceae27e70d73f5e40851886eb7", null ],
    [ "format_option_number", "classsrecord_1_1input__file__ti__tagged.html#afe4e3c676bc726526d1efa9c04871dd8", null ]
];