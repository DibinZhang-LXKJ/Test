var classsrecord_1_1memory__walker__compare =
[
    [ "pointer", "classsrecord_1_1memory__walker__compare.html#a92bb1447a8aeecd8d57538bf4c65ac97", null ],
    [ "~memory_walker_compare", "classsrecord_1_1memory__walker__compare.html#a0571f5bc0d0a3c46fd1d67afd7eb5e9f", null ],
    [ "observe", "classsrecord_1_1memory__walker__compare.html#a29036975fdcadf8379ebb4d61c944a8a", null ],
    [ "print", "classsrecord_1_1memory__walker__compare.html#a20ecbd089251a61e0cdf4c729fa943b0", null ],
    [ "same", "classsrecord_1_1memory__walker__compare.html#a4e3d7910ec6115bb95ae8b1ee7ec6538", null ]
];