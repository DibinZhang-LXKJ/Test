var classsrecord_1_1input__file__formatted__binary =
[
    [ "~input_file_formatted_binary", "classsrecord_1_1input__file__formatted__binary.html#a8c17b8dbda65aaea6ca32dbd44ff9ecf", null ],
    [ "read", "classsrecord_1_1input__file__formatted__binary.html#a498f340a76cfe3fb61ea833977842147", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__formatted__binary.html#a06161999e324f63b76222b73391f8d30", null ],
    [ "is_binary", "classsrecord_1_1input__file__formatted__binary.html#aa3164a539b01766fe48ebcb417191ded", null ],
    [ "format_option_number", "classsrecord_1_1input__file__formatted__binary.html#a75eb6aff29cca3875aeb32ec25a37ddf", null ]
];