var classsrecord_1_1input__file__ppx =
[
    [ "~input_file_ppx", "classsrecord_1_1input__file__ppx.html#a32f497fc3a602d72403d9a43f195b436", null ],
    [ "read", "classsrecord_1_1input__file__ppx.html#aca2de2c25489fb20b25433264cc8fb79", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__ppx.html#ad2bfa1b25c18cdedd00448c771de7158", null ],
    [ "format_option_number", "classsrecord_1_1input__file__ppx.html#adf38a05bc0340d36ac8fbe9b580ada59", null ]
];