var classsrecord_1_1input__file__ppb =
[
    [ "~input_file_ppb", "classsrecord_1_1input__file__ppb.html#a08c71cea84818a035c7bb8351e18ea5c", null ],
    [ "read", "classsrecord_1_1input__file__ppb.html#acfd023302e43699e3f141567ef957793", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__ppb.html#a249fe3ec2ec3a71d7dfe84e8231dfcad", null ],
    [ "is_binary", "classsrecord_1_1input__file__ppb.html#ae26092d7dd796809966296a09a86308b", null ],
    [ "format_option_number", "classsrecord_1_1input__file__ppb.html#a06e378f03c7320f79aa884bc7c7db3a8", null ]
];