var classsrecord_1_1input__file__os65v =
[
    [ "~input_file_os65v", "classsrecord_1_1input__file__os65v.html#a059f66ffc42d7a46616fa57e98b31073", null ],
    [ "read", "classsrecord_1_1input__file__os65v.html#abde2bdc327585a59e6bc26e03ad722d7", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__os65v.html#a250cffbfa15d0bab8bbcbfc663d893ed", null ],
    [ "format_option_number", "classsrecord_1_1input__file__os65v.html#a8b1862c9594da838f68c36e735a1fbb4", null ]
];