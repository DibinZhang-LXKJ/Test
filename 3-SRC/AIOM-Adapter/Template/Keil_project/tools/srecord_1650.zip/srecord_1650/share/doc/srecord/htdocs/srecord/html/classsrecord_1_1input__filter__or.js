var classsrecord_1_1input__filter__or =
[
    [ "~input_filter_or", "classsrecord_1_1input__filter__or.html#adce8c79b9ba47a1223494a0bfa01ebae", null ],
    [ "read", "classsrecord_1_1input__filter__or.html#ad8818077c1806a6a27f305876414542a", null ]
];