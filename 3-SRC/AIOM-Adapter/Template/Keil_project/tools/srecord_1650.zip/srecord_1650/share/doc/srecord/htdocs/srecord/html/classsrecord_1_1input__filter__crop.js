var classsrecord_1_1input__filter__crop =
[
    [ "~input_filter_crop", "classsrecord_1_1input__filter__crop.html#ab51b1f488edb04ac32e5eedcff1f9e25", null ],
    [ "read", "classsrecord_1_1input__filter__crop.html#a6ff6245cf97058d92b5fb37e5d3d2ef5", null ]
];