var classsrecord_1_1memory__walker__continuity =
[
    [ "pointer", "classsrecord_1_1memory__walker__continuity.html#a47a04c5ef6e38cf64447de54cf2b5fe1", null ],
    [ "~memory_walker_continuity", "classsrecord_1_1memory__walker__continuity.html#a50f41201f1a844860de71eba1aaf908a", null ],
    [ "is_continuous", "classsrecord_1_1memory__walker__continuity.html#a7b7a90802434e9a0bbc4ab1de4ec603b", null ],
    [ "observe", "classsrecord_1_1memory__walker__continuity.html#a16ad58bff4cac581d8ebccb263028bc3", null ]
];