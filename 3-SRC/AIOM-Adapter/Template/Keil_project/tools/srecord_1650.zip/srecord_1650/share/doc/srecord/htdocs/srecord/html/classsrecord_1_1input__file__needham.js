var classsrecord_1_1input__file__needham =
[
    [ "~input_file_needham", "classsrecord_1_1input__file__needham.html#a70bae1692735b4c11737e5aec313f974", null ],
    [ "read", "classsrecord_1_1input__file__needham.html#a652db4021b569f29fac397e5cacc8ff3", null ],
    [ "get_file_format_name", "classsrecord_1_1input__file__needham.html#a88e036b77a51cc457a738fbc060a87d5", null ],
    [ "format_option_number", "classsrecord_1_1input__file__needham.html#ac50cff1e50e8ad1f65a54426fb5f4eb7", null ]
];